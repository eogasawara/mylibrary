# Pacotes necessários
library(daltoolbox)
library(daltoolboxdp)
library(tspredit)
library(harbinger)
library(united)

## ------------------------------------------------------------
## 1) Preparação dos métodos (modelos) ----
## ------------------------------------------------------------
metodos <- list(
  hanr_fbiad(),  # Método 1: FBIAD
  hanr_arima()   # Método 2: ARIMA
)
names(metodos) <- c("fbiad", "arima")

## ------------------------------------------------------------
## 2) Preparação dos dados ----
## ------------------------------------------------------------
nome_base <- "gecco"
data(gecco)  # carrega a base 'gecco' no ambiente

# Fatiamos cada série no mesmo intervalo [16500:18000]
# OBS: ajuste este recorte se o tamanho das séries variar.
series_ts <- vector("list", length(gecco) - 1)
for (i in seq_along(series_ts)) {
  serie_nome <- names(gecco)[i]
  # Verificação de limites para evitar erro se a série for menor
  n <- nrow(gecco[[i]])
  inicio <- 16500L
  fim    <- 18000L
  if (is.null(n)) {
    stop(sprintf("Objeto %s não é um data.frame/ts esperado.", serie_nome))
  }
  if (fim > n) {
    stop(sprintf("Série %s tem apenas %d linhas; ajuste o recorte (%d:%d).",
                 serie_nome, n, inicio, fim))
  }
  series_ts[[i]] <- gecco[[i]][inicio:fim, ]
  names(series_ts)[i] <- serie_nome
}

## Garante diretório de resultados
dir.create("results", showWarnings = FALSE, recursive = TRUE)

## ------------------------------------------------------------
## 3) Detecção detalhada (com cache por método) ----
## ------------------------------------------------------------
detalhes_todos <- list()

for (j in seq_along(metodos)) {                 # percorre métodos
  modelo_atual   <- metodos[[j]]
  nome_modelo    <- names(metodos)[j]
  detalhes_modelo <- list()                     # resultados por série deste método
  
  # Caminho do arquivo de cache para este método
  arq_cache <- file.path("results", sprintf("exp_detail_%s.RData", nome_modelo))
  
  # Se existir resultado pré-computado, carregar para continuar de onde parou
  if (file.exists(arq_cache)) {
    load(file = arq_cache)  # carrega objeto 'detalhes_modelo' se salvo anteriormente
  }
  
  for (i in seq_along(series_ts)) {             # percorre séries
    dados_serie <- series_ts[[i]]
    nome_serie  <- names(series_ts)[i]
    
    # Se ainda não existe resultado para esta série, processa
    if (is.null(detalhes_modelo[i][[1]])) {
      tryCatch({
        ## 3.1 Ajuste (fit)
        inicio_tempo <- Sys.time()
        modelo_ajustado <- fit(modelo_atual, dados_serie$value)
        tempo_ajuste <- as.double(Sys.time() - inicio_tempo, units = "secs")
        
        ## 3.2 Detecção (detect)
        inicio_tempo <- Sys.time()
        resultado_detec <- detect(modelo_ajustado, dados_serie$value)
        tempo_deteccao <- as.double(Sys.time() - inicio_tempo, units = "secs")
        
        ## 3.3 Empacota resultado desta série
        detalhes_modelo[[i]] <- list(
          md          = modelo_ajustado,
          rs          = resultado_detec,
          dataref     = i,                 # índice da série no objeto series_ts
          modelname   = nome_modelo,
          datasetname = nome_base,
          seriesname  = nome_serie,
          time_fit    = tempo_ajuste,
          time_detect = tempo_deteccao
        )
        names(detalhes_modelo)[i] <- sprintf("%s_%s", nome_base, nome_serie)
        
        ## 3.4 Salva cache incremental (permite retomar em execuções futuras)
        save(detalhes_modelo, file = arq_cache, compress = "xz")
        
      }, error = function(e) {
        message(sprintf("Erro em %s - %s: %s", nome_modelo, nome_serie, e$message))
      })
    }
  }
  
  ## Acumula os detalhes deste método no agregado geral
  detalhes_todos <- c(detalhes_todos, detalhes_modelo)
}

## ------------------------------------------------------------
## 4) Sumário de desempenho (tempo e métricas) ----
## ------------------------------------------------------------
linhas_resumo <- vector("list", length(detalhes_todos))
for (k in seq_along(detalhes_todos)) {
  exp_k   <- detalhes_todos[[k]]
  dados_k <- series_ts[[exp_k$dataref]]
  
  # Avaliação "soft" com janela deslizante (ajuste sw_size conforme o caso)
  avaliacao_soft <- evaluate(har_eval_soft(sw_size = 10),
                             exp_k$rs$event, dados_k$event)
  
  # Linha do resumo para esta série e método
  linhas_resumo[[k]] <- data.frame(
    method      = exp_k$modelname,
    dataset     = exp_k$datasetname,
    series      = exp_k$seriesname,
    time_fit    = exp_k$time_fit,
    time_detect = exp_k$time_detect,
    precision   = avaliacao_soft$precision,
    recall      = avaliacao_soft$recall,
    f1          = avaliacao_soft$F1,
    stringsAsFactors = FALSE
  )
}

resumo_experimentos <- do.call(rbind, linhas_resumo)

## ------------------------------------------------------------
## 5) Persistência do sumário ----
## ------------------------------------------------------------
save(resumo_experimentos,
     file = file.path("results", "exp_summary.RData"),
     compress = "xz")
